$(document).on('ready turbo:load', function() {
    console.log('jalo')
});
