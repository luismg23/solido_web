// app/channels/index.js
// Importmaps don't require anything here;
