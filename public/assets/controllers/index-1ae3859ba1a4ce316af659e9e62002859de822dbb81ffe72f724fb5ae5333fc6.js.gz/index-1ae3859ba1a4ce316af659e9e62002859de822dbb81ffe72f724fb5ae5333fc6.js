import HomeController from './home_controller.js'
application.register('home', HomeController);
