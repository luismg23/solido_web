import ApplicationController from '../lib/application_controller'

export default class extends ApplicationController {
  initialize() {
    console.log('aloha');
  }
};
