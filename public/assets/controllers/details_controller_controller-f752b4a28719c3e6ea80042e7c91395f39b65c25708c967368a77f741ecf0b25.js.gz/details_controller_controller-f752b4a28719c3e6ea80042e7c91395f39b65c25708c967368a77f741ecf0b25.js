import ApplicationController from '../lib/application_controller'

export default class extends ApplicationController {
    console.log('hola')
};
