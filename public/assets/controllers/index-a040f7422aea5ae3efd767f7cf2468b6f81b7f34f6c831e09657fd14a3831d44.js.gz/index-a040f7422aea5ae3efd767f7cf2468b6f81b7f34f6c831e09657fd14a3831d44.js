import HomeController from './controllers/home_controller.js'
application.register('home', HomeController);
