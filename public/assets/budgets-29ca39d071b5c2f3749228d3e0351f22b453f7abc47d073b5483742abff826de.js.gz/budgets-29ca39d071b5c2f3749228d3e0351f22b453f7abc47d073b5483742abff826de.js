document.addEventListener('DOMContentLoaded', function() {
    const crearButton = document.getElementById('budget_create');
  
    crearButton.addEventListener('click', function() {
        $('#myModal').modal('show');
    })
});  
