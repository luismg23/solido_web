import consumer from "channels/consumer"
import CableReady from "cable_ready"

CableReady.initialize({ consumer });
