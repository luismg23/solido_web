console.log("entro");


Rails.start();
debounced.initialize({ ...debounced.events, keyup: { wait: 400 } })
;
