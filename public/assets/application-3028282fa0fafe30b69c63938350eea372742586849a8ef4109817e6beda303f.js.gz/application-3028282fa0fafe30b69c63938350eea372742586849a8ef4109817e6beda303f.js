// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"
import "jquery3"
import "popper"
import "bootstrap-sprockets"
import "rails-ujs"
import "activestorage"
import "turbolinks"
import "require_tree";
