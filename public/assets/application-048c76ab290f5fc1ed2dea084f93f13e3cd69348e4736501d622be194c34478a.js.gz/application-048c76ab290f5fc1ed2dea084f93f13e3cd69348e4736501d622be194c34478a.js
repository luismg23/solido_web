
console.log('prueba')
import "@hotwired/turbo-rails"
import "controllers"
import "jquery3"
import "popper"
import "bootstrap-sprockets"
import "rails-ujs"
import "activestorage"
import "turbolinks"
import "require_tree"

Rails.start();
debounced.initialize({ ...debounced.events, keyup: { wait: 400 } })
;
