document.addEventListener('DOMContentLoaded', function() {
  console.log('jalo?')
  $('#myModal').modal('show');
});
