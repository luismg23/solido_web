document.addEventListener('DOMContentLoaded', function() {
  $('#myModal').modal('show');
});
