document.addEventListener('turbo:load', function() {
    console.log('jalo')
  });
  
